/* 天象预报编辑器 · 核心逻辑（纯函数，浏览器与 Node 通用）
   —— 负责：新建/复制月份、把月份对象转成网站数据代码、生成整年数据文件、快速文本导入、数据校验 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) { module.exports = api; }
  root.EDITOR = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var KINDS = ["流星雨", "行星", "日月食", "节气", "深空", "彗星", "月相", "其他"];
  var PHASES = ["朔", "上弦", "望", "下弦"];
  var MONTH_NAMES = ["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"];
  var MONTH_ALIAS = [
    "正月 · 端月","杏月 · 花月","桃月 · 蚕月","清和月 · 槐月","皋月 · 榴月","荷月 · 季月",
    "巧月 · 兰月","桂月 · 壮月","菊月 · 霜月","阳月 · 良月","冬月 · 辜月","腊月 · 涂月"
  ];

  function q(s) { return JSON.stringify(String(s == null ? "" : s)); }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function todayStr() { var d = new Date(); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); }
  function isDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || "")); }
  function monthId(y, m) { return y + "-" + pad2(m); }

  /* 空白月份（用于“新建月份”） */
  function blankMonth(year, month) {
    return {
      id: monthId(year, month), year: year, month: month,
      name: MONTH_NAMES[month - 1], alias: MONTH_ALIAS[month - 1],
      quote: "", intro: "", season: "",
      terms: [{ n: "", d: "", t: "" }, { n: "", d: "", t: "" }],
      phases: PHASES.map(function (n) { return { n: n, d: "", t: "" }; }),
      planets: [{ n: "", t: "" }],
      events: [{ d: "", k: "流星雨", lv: 3, t: "", desc: "", tip: "" }],
      outro: "", official: ""
    };
  }

  /* 下一个待写的月份（在已有月份之后） */
  function nextMonth(months) {
    if (!months || !months.length) return { year: new Date().getFullYear(), month: 1 };
    var last = months.slice().sort(function (a, b) { return String(a.id).localeCompare(String(b.id)); }).pop();
    var y = last.year, m = last.month + 1;
    if (m > 12) { m = 1; y += 1; }
    return { year: y, month: m };
  }

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  /* 月份对象 → 网站数据代码 */
  function monthToJS(m) {
    var parts = [];
    parts.push("  id: " + q(m.id) + ", year: " + m.year + ", month: " + m.month + ", name: " + q(m.name) + ", alias: " + q(m.alias || ""));
    parts.push("  quote: " + q(m.quote || ""));
    parts.push("  intro: " + q(m.intro || ""));
    parts.push("  season: " + q(m.season || ""));
    var terms = (m.terms || []).filter(function (t) { return t && (t.n || t.d); }).map(function (t) {
      return "{ n: " + q(t.n) + ", d: " + q(t.d) + (t.t ? ", t: " + q(t.t) : "") + " }";
    });
    parts.push("  terms: [" + terms.join(", ") + "]");
    var phases = (m.phases || []).filter(function (p) { return p && (p.n || p.d); }).map(function (p) {
      return "{ n: " + q(p.n) + ", d: " + q(p.d) + (p.t ? ", t: " + q(p.t) : "") + " }";
    });
    parts.push("  phases: [" + phases.join(", ") + "]");
    var planets = (m.planets || []).filter(function (p) { return p && (p.n || p.t); }).map(function (p) {
      return "    { n: " + q(p.n) + ", t: " + q(p.t) + " }";
    });
    parts.push("  planets: [\n" + planets.join(",\n") + "\n  ]");
    var events = (m.events || []).filter(function (e) { return e && (e.t || e.d); }).map(function (e) {
      return "    { d: " + q(e.d) + ", k: " + q(e.k) + ", lv: " + (Number(e.lv) || 1) + ", t: " + q(e.t) +
        ", desc: " + q(e.desc || "") + (e.tip ? ", tip: " + q(e.tip) : "") + " }";
    });
    parts.push("  events: [\n" + events.join(",\n") + "\n  ]");
    if (m.outro) parts.push("  outro: " + q(m.outro));
    if (m.official) parts.push("  official: " + q(m.official));
    return "{\n" + parts.join(",\n") + "\n}";
  }

  /* 某一年全部月份 → 一个完整的数据文件内容 */
  function buildFile(months, year) {
    var list = (months || []).filter(function (m) { return Number(m.year) === Number(year); })
      .sort(function (a, b) { return String(a.id).localeCompare(String(b.id)); });
    var head = [
      "/* 广大天协 · 天象预报数据（" + year + "年）",
      "   由「天象预报编辑器」生成（tools/forecast-editor.html），也可手动编辑。",
      "   数据来源请在每月推文的参考资料中一并列出：有趣天文奇观（紫金山天文台数据）、天文通、",
      "   紫金山天文台科普部、Stellarium、In-The-Sky.org 等。",
      "   日期与时刻均为北京时间（UTC+8）。 */",
      'window.SKY_DATA = window.SKY_DATA || { updated: "' + todayStr() + '", months: [] };',
      "window.SKY_DATA.months.push("
    ].join("\n");
    return head + "\n" + list.map(monthToJS).join(",\n") + "\n);\n";
  }

  /* 快速文本导入 */
  function parseQuick(text, fallbackYear) {
    var m = blankMonth(fallbackYear || new Date().getFullYear(), 1);
    m.terms = []; m.phases = []; m.planets = []; m.events = [];
    var errors = [];
    var lines = String(text || "").split(/\r?\n/);
    var headerSeen = false;
    lines.forEach(function (raw, i) {
      var line = raw.trim();
      if (!line) return;
      if (line.charAt(0) === "#") {
        var head = line.replace(/^#+\s*/, "");
        var mm = head.match(/(\d{4})[-\/年](\d{1,2})/);
        if (mm) {
          m.year = Number(mm[1]); m.month = Number(mm[2]); m.id = monthId(m.year, m.month);
          m.name = MONTH_NAMES[m.month - 1];
          m.alias = MONTH_ALIAS[m.month - 1];
          var rest = head.replace(mm[0], "").replace(/^[\s月]+/, "").trim();
          if (rest) m.name = rest;
        }
        headerSeen = true;
        return;
      }
      var kv = line.match(/^([A-Za-z\u4e00-\u9fa5]+)\s*[:：]\s*([\s\S]*)$/);
      if (!kv) { errors.push("第 " + (i + 1) + " 行无法识别：" + line.slice(0, 30)); return; }
      var key = kv[1].toLowerCase(), val = kv[2].trim();
      var f = val.split(/\s*[|｜]\s*/);
      switch (key) {
        case "id": var p = val.match(/(\d{4})-(\d{1,2})/); if (p) { m.year = Number(p[1]); m.month = Number(p[2]); m.id = monthId(m.year, m.month); } break;
        case "name": m.name = val; break;
        case "alias": m.alias = val; break;
        case "quote": m.quote = val; break;
        case "intro": m.intro = val; break;
        case "season": m.season = val; break;
        case "outro": m.outro = val; break;
        case "official": case "url": m.official = val; break;
        case "term": m.terms.push({ n: f[0] || "", d: f[1] || "", t: f[2] || "" }); break;
        case "phase": m.phases.push({ n: f[0] || "", d: f[1] || "", t: f[2] || "" }); break;
        case "planet": m.planets.push({ n: f[0] || "", t: f[1] || "" }); break;
        case "event": m.events.push({ d: f[0] || "", k: f[1] || "其他", lv: Number(f[2]) || 1, t: f[3] || "", desc: f[4] || "", tip: f[5] || "" }); break;
        default: errors.push("未知字段「" + kv[1] + "」（第 " + (i + 1) + " 行）");
      }
    });
    if (!headerSeen) errors.push("缺少标题行，例如：# 2027-01 一月");
    if (!m.phases.length) m.phases = PHASES.map(function (n) { return { n: n, d: "", t: "" }; });
    if (!m.terms.length) m.terms = [{ n: "", d: "", t: "" }, { n: "", d: "", t: "" }];
    if (!m.planets.length) m.planets = [{ n: "", t: "" }];
    if (!m.events.length) m.events = [{ d: "", k: "流星雨", lv: 3, t: "", desc: "", tip: "" }];
    return { month: m, errors: errors };
  }

  /* 校验 */
  function validate(m) {
    var errors = [], warnings = [];
    if (!/^\d{4}-\d{2}$/.test(String(m.id || ""))) errors.push("id 必须是 YYYY-MM，例如 2027-01");
    if (m.id !== monthId(m.year, m.month)) errors.push("id（" + m.id + "）与 year/month 不一致");
    if (!m.name) errors.push("缺少月份名称");
    if (!m.intro) warnings.push("导语（intro）为空，页面会少一段介绍");
    if (!m.quote) warnings.push("诗句（quote）为空");
    if (!m.season) warnings.push("星空看点（season）为空");
    var inMonth = function (d) { return isDate(d) && d.slice(0, 7) === m.id; };
    if ((m.terms || []).filter(function (t) { return t.n; }).length < 2) warnings.push("节气建议填写 2 个");
    (m.terms || []).forEach(function (t) { if (t.n && !inMonth(t.d)) errors.push("节气「" + t.n + "」的日期不在 " + m.id); });
    if ((m.phases || []).filter(function (p) { return p.d; }).length < 4) warnings.push("月相建议填写 4 个（朔/上弦/望/下弦）");
    (m.phases || []).forEach(function (p) { if (p.d && !inMonth(p.d)) errors.push("月相「" + p.n + "」的日期不在 " + m.id); });
    var evs = (m.events || []).filter(function (e) { return e.t || e.d; });
    if (!evs.length) errors.push("至少需要一条天象事件");
    evs.forEach(function (e) {
      if (!isDate(e.d)) errors.push("事件「" + (e.t || "(未命名)") + "」日期格式应为 YYYY-MM-DD");
      else if (!inMonth(e.d)) warnings.push("事件「" + e.t + "」的日期 " + e.d + " 不在 " + m.id + "（跨月事件可忽略）");
      if (!e.t) errors.push("有事件缺少标题");
      if (KINDS.indexOf(e.k) < 0) warnings.push("事件「" + e.t + "」的类型「" + e.k + "」不在推荐列表内");
      if (!(Number(e.lv) >= 1 && Number(e.lv) <= 3)) warnings.push("事件「" + e.t + "」的推荐等级应为 1—3");
    });
    if (!m.outro) warnings.push("尾声（outro）为空");
    return { errors: errors, warnings: warnings };
  }

  function yearsOf(months) {
    var set = {};
    (months || []).forEach(function (m) { set[m.year] = true; });
    return Object.keys(set).map(Number).sort();
  }

  return {
    KINDS: KINDS, PHASES: PHASES, MONTH_NAMES: MONTH_NAMES, MONTH_ALIAS: MONTH_ALIAS,
    blankMonth: blankMonth, nextMonth: nextMonth, clone: clone, monthId: monthId,
    monthToJS: monthToJS, buildFile: buildFile, parseQuick: parseQuick, validate: validate,
    yearsOf: yearsOf, isDate: isDate, todayStr: todayStr
  };
});
