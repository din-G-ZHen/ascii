/* 广大天协 · 天象预报数据（2027年）
   本文件当前为空，用于放置 2027 年的月度天象预报。
   推荐用网站自带的「天象预报编辑器」生成：tools/forecast-editor.html
   日期与时刻均为北京时间（UTC+8）。 */
window.SKY_DATA = window.SKY_DATA || { updated: "2026-10-16", months: [] };
/* window.SKY_DATA.months.push(
{
  id: "2027-01", year: 2027, month: 1, name: "一月", alias: "正月 · 端月",
  ...
}
); */
