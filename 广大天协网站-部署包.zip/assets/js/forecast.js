/* 天象预报专区脚本 */
(function () {
  "use strict";
  var A = window.APP, $ = A.$, $$ = A.$$, esc = A.esc;
  var DATA = window.SKY_DATA || { months: [] };
  var MONTHS = DATA.months.slice().sort(function (a, b) { return a.id.localeCompare(b.id); });
  var state = { month: null, type: "全部", q: "" };

  var TYPE_CLASS = {
    "流星雨": "cyan", "行星": "violet", "日月食": "gold", "节气": "pink",
    "深空": "cyan", "彗星": "gold", "月相": "violet", "其他": ""
  };
  var LV_TEXT = { 3: "强烈推荐", 2: "推荐", 1: "关注" };

  function monthOf(id) { for (var i = 0; i < MONTHS.length; i++) if (MONTHS[i].id === id) return MONTHS[i]; return null; }

  /* ---------- 月份导航 ---------- */
  function rail() {
    var box = $("#month-rail");
    if (!box) return;
    var today = A.todayStr().slice(0, 7);
    box.innerHTML = MONTHS.map(function (m) {
      return '<button data-id="' + m.id + '" class="' + (m.id === today ? "today" : "") + '">' +
        '<b>' + m.year + '.' + A.pad(m.month) + '</b><span>' + esc(m.name) + '</span></button>';
    }).join("");
    $$("button", box).forEach(function (b) {
      b.addEventListener("click", function () { state.type = "全部"; state.q = ""; syncFilters(); select(b.getAttribute("data-id")); });
    });
  }

  function select(id) {
    state.month = id;
    $$("#month-rail button").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-id") === id); });
    var m = monthOf(id);
    if (m) renderMonth(m);
  }

  /* ---------- 月度面板 ---------- */
  function renderMonth(m) {
    var host = $("#month-panel");
    if (!host) return;
    host.classList.remove("single");
    var termChips = (m.terms || []).map(function (t) { return '<span class="chip pink">' + esc(t.n) + ' ' + A.fmtMD(t.d) + (t.t ? " " + esc(t.t) : "") + '</span>'; }).join("");
    var phaseRows = (m.phases || []).map(function (p) { return '<div><span>' + esc(p.n) + '</span><b>' + A.fmtMD(p.d) + (p.t ? " " + esc(p.t) : "") + ' 周' + A.weekday(p.d) + '</b></div>'; }).join("");
    var planets = (m.planets || []).map(function (p) { return '<div class="planet-row"><b>' + esc(p.n) + '</b><span>' + esc(p.t) + '</span></div>'; }).join("");
    var events = (m.events || []).slice().sort(function (a, b) { return String(a.d).localeCompare(String(b.d)); }).map(function (e) { return evHtml(e, m.terms); }).join("");

    host.innerHTML =
      '<div class="card reveal in">' +
        '<div class="month-head">' +
          '<h3>' + m.year + ' 年 ' + esc(m.name) + '</h3>' +
          '<span class="chip">' + esc(m.alias || "") + '</span>' +
          termChips +
          '<span class="chip gold">' + (m.events || []).length + ' 项天象</span>' +
        '</div>' +
        '<div class="month-quote">' + esc(m.quote || "") + '</div>' +
        '<p style="color:var(--ink-2)">' + esc(m.intro || "") + '</p>' +
        (m.season ? '<p class="small muted"><b style="color:var(--cyan-2)">星空看点　</b>' + esc(m.season) + '</p>' : '') +
        '<h4 style="margin:22px 0 10px;font-size:15px;letter-spacing:2px;color:var(--cyan)">本月天象</h4>' +
        '<div class="ev-list">' + (events || '<p class="muted small">暂无记录</p>') + '</div>' +
        (m.outro ? '<p class="month-quote" style="margin-top:20px">' + esc(m.outro) + '</p>' : '') +
        (m.official ? '<p class="small"><a class="btn ghost" target="_blank" rel="noopener" href="' + esc(m.official) + '">阅读公众号原文 · ' + m.year + ' 年 ' + m.month + ' 月天象预报 →</a></p>' : '') +
        '<p class="src-note">数据整理：广大天协网站编辑部 ｜ 参考：有趣天文奇观年度历表（紫金山天文台数据）、In-The-Sky.org 天文事件日历、香港天文台节气与月相资料、日本国立天文台 NAOJ、台北市立天文科学教育馆、NASA 日月食资料、Stellarium。所有时刻均为北京时间，月相与节气时刻经香港天文台与日本国立天文台双源核对。日期均为北京时间，行星动态依据冲日／合日／大距等可核验天象编写，实际观测请以临近预报为准。</p>' +
      '</div>' +
      '<div>' +
        '<div class="card side-block reveal in">' +
          '<h4>月相节点</h4><div class="kv">' + phaseRows + '</div>' +
          '<div class="moon-mini" id="month-moon" style="margin-top:14px"></div>' +
        '</div>' +
        '<div class="card side-block reveal in">' +
          '<h4>行星动态</h4>' + planets +
        '</div>' +
        '<div class="card side-block reveal in">' +
          '<h4>观测小贴士</h4>' +
          '<p class="small muted" style="margin:0">' + esc(tipsFor(m)) + '</p>' +
        '</div>' +
      '</div>';

    var mm = $("#month-moon");
    if (mm) mm.innerHTML = moonLine(m.phases && m.phases[0] ? m.phases[0].d : m.id + "-15");
    bindEvents(host, m);
  }

  function tipsFor(m) {
    var tips = {
      9: "秋夜渐凉，露水重，请备好防潮垫与外套；拍摄银河建议在日落后 1—2 小时内完成。",
      10: "早晚温差大，注意保暖；行星观测建议带上星图与红光手电。",
      11: "冬季星空通透，适合深空观测；长时间守候流星雨请准备热水与厚衣。",
      12: "全年夜最长，注意防寒；相机电池在低温下掉电快，建议备双份。",
      1: "冬季观星务必做好保暖，重点推荐木星与冬季深空目标。",
      2: "傍晚行星观测窗口较短，建议提前踩点、架好器材。",
      3: "春季天气多变，抓住雨后初晴的通透夜晚；月食建议提前查好月出方位。",
      4: "春季大三角与星系季末期，适合双筒望远镜巡天；黎明观测需提前 40 分钟到位。",
      5: "银河东升，注意地面湿气；流星雨观测建议躺在防潮垫上以扩大视野。",
      6: "夏夜蚊虫多，备好驱蚊用品；银河核心在午夜前后最佳，注意结露。",
      7: "盛夏观星注意防暑与补水；银河拱桥拍摄建议使用广角镜头加大光圈。",
      8: "英仙座流星雨是本月重点，提前选好远离灯光、视野开阔的观测点。"
    };
    return tips[m.month] || "选择远离城市灯光、视野开阔的地点；出发前查询天气预报与月相。";
  }

  function moonLine(dateStr) {
    var d = new Date(dateStr + "T20:00:00");
    if (isNaN(d.getTime())) return "";
    var p = A.moonPhase(d);
    return '<div class="small muted">以 ' + A.fmtMD(dateStr) + ' 为例：' + p.emoji + ' ' + esc(p.name) + '，月面照亮约 ' + Math.round(p.illum * 100) + '%（近似值）。</div>';
  }

  function evHtml(e, terms) {
    var termTime = "";
    if (e.k === "节气" && terms) {
      for (var ti = 0; ti < terms.length; ti++) {
        if (terms[ti].n === e.t && terms[ti].t) termTime = terms[ti].d + " " + terms[ti].t;
      }
    }
    return '<div class="ev" data-ev="' + esc(e.t) + '">' +
      '<div class="ev-date">' + A.fmtMD(e.d) + '<span>' + A.weekday(e.d) + ' · ' + esc(LV_TEXT[e.lv] || "") + '</span></div>' +
      '<div><h4><span class="chip ' + (TYPE_CLASS[e.k] || "") + '">' + esc(e.k) + '</span>' + esc(e.t) + '</h4>' +
      '<p>' + esc(e.desc) + (termTime ? ' <span class="chip pink">交节时刻 北京时间 ' + esc(termTime.slice(5)) + '</span>' : '') + '</p>' +
      (e.tip ? '<div class="tips">观测提示：' + esc(e.tip) + '　<span class="moon-tag">' + esc(A.moonTag(e.d)) + '</span></div>' : '') +
      '</div></div>';
  }

  function bindEvents(host, m) {
    $$(".ev", host).forEach(function (el) {
      el.addEventListener("click", function () {
        var title = el.getAttribute("data-ev");
        var ev = (m.events || []).filter(function (x) { return x.t === title; })[0];
        if (ev) openModal(ev, m);
      });
    });
  }

  function openModal(e, m) {
    var box = $("#modal");
    if (!box) return;
    box.innerHTML = '<div class="modal-box"><button class="modal-close" aria-label="关闭">✕</button>' +
      '<div class="art-meta"><span class="chip ' + (TYPE_CLASS[e.k] || "") + '">' + esc(e.k) + '</span>' +
      '<span class="chip gold">' + esc(LV_TEXT[e.lv] || "") + '</span>' +
      '<span>' + A.fmtDate(e.d) + ' 星期' + A.weekday(e.d) + '</span></div>' +
      '<h3 style="margin-top:12px">' + esc(e.t) + '</h3>' +
      '<p>' + esc(e.desc) + '</p>' +
      (e.tip ? '<p class="muted"><b style="color:var(--gold-2)">观测提示：</b>' + esc(e.tip) + '</p>' : '') +
      '<p class="small muted">' + esc(A.moonTag(e.d)) + '</p>' +
      '<p class="src-note">所属月份：' + m.year + ' 年 ' + m.month + ' 月天象预报 ｜ 整理：广大天协网站编辑部</p>' +
      '</div>';
    box.classList.add("on");
    $(".modal-close", box).addEventListener("click", function () { box.classList.remove("on"); });
    box.addEventListener("click", function (ev2) { if (ev2.target === box) box.classList.remove("on"); });
  }

  /* ---------- 筛选与搜索 ---------- */
  function syncFilters() {
    $$("#type-filters button").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-t") === state.type); });
    var inp = $("#search-input");
    if (inp && inp.value !== state.q) inp.value = state.q;
  }

  function allEvents() {
    var out = [];
    MONTHS.forEach(function (m) { (m.events || []).forEach(function (e) { out.push({ m: m, e: e }); }); });
    return out.sort(function (a, b) { return String(a.e.d).localeCompare(String(b.e.d)); });
  }

  function renderFiltered() {
    var host = $("#month-panel");
    if (!host) return;
    var list = allEvents().filter(function (x) {
      if (state.type !== "全部" && x.e.k !== state.type) return false;
      if (state.q) {
        var s = (x.e.t + x.e.desc + x.e.tip + x.e.k + x.m.name + x.m.year).toLowerCase();
        if (s.indexOf(state.q.toLowerCase()) < 0) return false;
      }
      return true;
    });
    host.classList.add("single");
    var head = '<div class="card" style="margin-bottom:18px"><h3 style="font-family:var(--font-title);font-size:22px">筛选结果</h3>' +
      '<p class="muted small">条件：' + (state.type === "全部" ? "全部类型" : esc(state.type)) + (state.q ? " · 关键词「" + esc(state.q) + "」" : "") + ' · 共 ' + list.length + ' 项</p>' +
      '<div class="row" style="margin-top:10px"><button class="btn ghost" id="reset-filter">重置筛选，回到月度视图</button></div></div>';
    var rows = list.map(function (x) {
      return '<div class="ev" data-ev2="' + esc(x.e.d + "|" + x.e.t) + '">' +
        '<div class="ev-date">' + A.fmtMD(x.e.d) + '<span>' + x.m.year + '.' + A.pad(x.m.month) + '</span></div>' +
        '<div><h4><span class="chip ' + (TYPE_CLASS[x.e.k] || "") + '">' + esc(x.e.k) + '</span>' + esc(x.e.t) + '</h4>' +
        '<p>' + esc(x.e.desc) + '</p></div></div>';
    }).join("");
    host.innerHTML = head + '<div class="ev-list">' + (rows || '<p class="muted">没有找到符合条件的天象，换个关键词试试。</p>') + '</div>';
    var rb = $("#reset-filter");
    if (rb) rb.addEventListener("click", function () { state.type = "全部"; state.q = ""; syncFilters(); select(state.month || MONTHS[MONTHS.length - 1].id); });
    $$(".ev", host).forEach(function (el) {
      el.addEventListener("click", function () {
        var parts = el.getAttribute("data-ev2").split("|");
        var found = allEvents().filter(function (x) { return x.e.t === parts[1] && x.e.d === parts[0]; })[0];
        if (found) openModal(found.e, found.m);
      });
    });
  }

  /* ---------- 月相表盘（SVG 路径绘制） ---------- */
  function moonDialSVG(p) {
    var r = 56, cx = 64, cy = 64;
    var f = Math.max(0.001, Math.min(0.999, p.illum));
    var waxing = p.age < 14.765;
    var a = Math.max(0.6, r * Math.abs(2 * f - 1));
    var limbSweep = waxing ? 1 : 0;
    var innerSweep = f > 0.5 ? limbSweep : 1 - limbSweep;
    var path = "M " + cx + " " + (cy - r) +
      " A " + r + " " + r + " 0 0 " + limbSweep + " " + cx + " " + (cy + r) +
      " A " + a.toFixed(2) + " " + r + " 0 0 " + innerSweep + " " + cx + " " + (cy - r) + " Z";
    return '<svg viewBox="0 0 128 128" width="150" height="150" role="img" aria-label="月相示意">' +
      '<defs>' +
      '<radialGradient id="mg1" cx="0.36" cy="0.32" r="0.75"><stop offset="0%" stop-color="#fffdf3"/><stop offset="62%" stop-color="#e9e3ca"/><stop offset="100%" stop-color="#c8c0a4"/></radialGradient>' +
      '<clipPath id="mgclip"><path d="' + path + '"/></clipPath>' +
      '<radialGradient id="mg2" cx="0.5" cy="0.5" r="0.5"><stop offset="60%" stop-color="#8fd8ff" stop-opacity="0.35"/><stop offset="100%" stop-color="#8fd8ff" stop-opacity="0"/></radialGradient>' +
      '</defs>' +
      '<circle cx="64" cy="64" r="72" fill="url(#mg2)"/>' +
      '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="#0b0e24" stroke="rgba(140,160,255,.3)"/>' +
      '<path d="' + path + '" fill="url(#mg1)"/>' +
      '<g clip-path="url(#mgclip)" opacity="0.5" fill="#b9b096">' +
      '<circle cx="46" cy="46" r="9"/><circle cx="80" cy="66" r="6"/><circle cx="58" cy="86" r="7"/><circle cx="88" cy="38" r="4"/><circle cx="36" cy="74" r="4.5"/>' +
      '</g>' +
      '</svg>';
  }

  /* ---------- 本月天象 / 倒计时 ---------- */
  function nowSection() {
    var host = $("#now-body");
    if (!host) return;
    var today = A.todayStr();
    var curId = today.slice(0, 7);
    var m = monthOf(curId) || MONTHS[MONTHS.length - 1];
    var upcoming = (m.events || []).slice().sort(function (a, b) { return String(a.d).localeCompare(String(b.d)); });
    var future = upcoming.filter(function (e) { return e.d >= today; });
    var showList = (future.length ? future : upcoming).slice(0, 5);

    host.innerHTML =
      '<div class="card now-card reveal in">' +
        '<h3 class="now-title">' + m.year + ' 年 ' + esc(m.name) + '天象预报 <span class="chip gold">' + esc(m.alias) + '</span></h3>' +
        '<p class="muted small" style="margin:0">' + esc(m.intro || "") + '</p>' +
        '<ul class="now-list">' + showList.map(function (e) {
          return '<li><span class="d">' + A.fmtMD(e.d) + '</span><span><b style="color:#fff">' + esc(e.t) + '</b>　<span class="chip ' + (TYPE_CLASS[e.k] || "") + '">' + esc(e.k) + '</span><br><span class="small muted">' + esc(e.desc) + '</span></span></li>';
        }).join("") + '</ul>' +
        '<p class="src-note">完整内容见下方月度档案；公众号「南三角天文社」每月同步发布。</p>' +
      '</div>' +
      '<div>' +
        '<div class="card reveal in" style="margin-bottom:18px">' +
          '<h4 style="font-size:14px;letter-spacing:2px;color:var(--cyan);text-transform:uppercase">距离下一场天象</h4>' +
          '<p class="small muted" id="cd-name" style="margin:6px 0 0">正在计算…</p>' +
          '<div class="countdown"><div><b id="cd-d">--</b><span>天</span></div><div><b id="cd-h">--</b><span>时</span></div><div><b id="cd-m">--</b><span>分</span></div><div><b id="cd-s">--</b><span>秒</span></div></div>' +
        '</div>' +
        '<div class="card reveal in">' +
          '<h4 style="font-size:14px;letter-spacing:2px;color:var(--cyan);text-transform:uppercase">月相查询器</h4>' +
          '<div class="moon-tool" style="margin-top:14px">' +
            '<div class="moon-dial" id="moon-dial"></div>' +
            '<div class="moon-meta">' +
              '<b id="moon-name">—</b>' +
              '<div>月面照亮：<span id="moon-illum">—</span></div>' +
              '<div>月龄：<span id="moon-age">—</span></div>' +
              '<div class="small muted" id="moon-note" style="margin-top:6px">正在计算…</div>' +
            '</div>' +
          '</div>' +
          '<div class="toolbar" style="margin:16px 0 0">' +
            '<div class="field"><input type="date" id="moon-date"></div>' +
            '<button class="btn ghost" id="moon-today">今天</button>' +
          '</div>' +
          '<div style="margin-top:16px;border-top:1px dashed var(--line);padding-top:14px">' +
            '<div class="toolbar" style="margin:0 0 10px">' +
              '<div class="field"><span class="small muted">观测地</span><select id="moon-city"></select></div>' +
              '<span class="small muted" id="moon-coord"></span>' +
            '</div>' +
            '<div class="kv">' +
              '<div><span>月出</span><b id="moon-rise">—</b></div>' +
              '<div><span>中天（最高）</span><b id="moon-tran">—</b></div>' +
              '<div><span>月落</span><b id="moon-set">—</b></div>' +
            '</div>' +
            '<p class="small" id="moon-now" style="margin:6px 0 0;color:var(--ink-2)"></p>' +
            '<p class="src-note" style="margin-top:6px">按含蒙气差与视差的几何高度计算，与香港天文台官方月出月落数据比对误差通常在 2 分钟内。</p>' +
          '</div>' +
          '<div style="margin-top:16px;border-top:1px dashed var(--line);padding-top:14px">' +
            '<h4 style="font-size:12.5px;letter-spacing:2px;color:var(--cyan);text-transform:uppercase;margin:0 0 8px">下一次朔 / 上弦 / 望 / 下弦</h4>' +
            '<div class="kv" id="moon-next"></div>' +
          '</div>' +
        '</div>' +
      '</div>';

    var next = allEvents().filter(function (x) { return x.e.d >= today; })[0];
    if (!next) next = allEvents()[allEvents().length - 1];
    var nm = $("#cd-name");
    if (nm && next) nm.innerHTML = '<b style="color:#fff">' + esc(next.e.t) + '</b> · ' + A.fmtDate(next.e.d) + '（' + esc(next.e.k) + '，' + esc(next.m.year + "年" + next.m.name) + '）';
    if (next) {
      var target = new Date(next.e.d + "T00:00:00").getTime();
      var tick = function () {
        var diff = target - Date.now();
        if (diff < 0) diff = 0;
        var d = Math.floor(diff / 86400000), h = Math.floor(diff % 86400000 / 3600000),
          mi = Math.floor(diff % 3600000 / 60000), se = Math.floor(diff % 60000 / 1000);
        $("#cd-d").textContent = d; $("#cd-h").textContent = A.pad(h);
        $("#cd-m").textContent = A.pad(mi); $("#cd-s").textContent = A.pad(se);
      };
      tick(); setInterval(tick, 1000);
    }

    var input = $("#moon-date");
    var followed = today;            /* 记住自动写入的日期，用于跨零点自动跟随 */
    input.value = followed;
    var upd = function () {
      var sel = input.value || A.todayStr();
      var isToday = (sel === A.todayStr());
      var d = isToday ? new Date() : new Date(sel + "T20:00:00");
      if (isNaN(d.getTime())) return;
      var p = A.moonPhase(d);
      $("#moon-name").textContent = p.emoji + " " + p.name;
      $("#moon-illum").textContent = Math.round(p.illum * 100) + "%";
      $("#moon-age").textContent = p.age.toFixed(1) + " 天";
      var dial = $("#moon-dial");
      if (dial) dial.innerHTML = moonDialSVG(p);
      var clock = A.pad(d.getHours()) + ":" + A.pad(d.getMinutes());
      var note;
      if (p.method === "exact") {
        note = isToday
          ? "实时计算：此刻（" + clock + "），每 30 秒自动刷新；照明度按精确朔望时刻插值。"
          : "按 " + A.fmtMD(sel) + " 20:00 计算；照明度按精确朔望时刻插值。";
      } else {
        note = "该日期超出已整理的数据范围，改用平均朔望周期近似算法（误差约 ±0.5 天）。";
      }
      $("#moon-note").textContent = note;
    };
    /* ---- 月出 / 中天 / 月落（按观测地计算） ---- */
    var MP = window.MOONPOS;
    var cities = (MP && MP.CITIES) || [];
    var cityIdx = 0;
    var citySel = $("#moon-city");
    if (citySel && cities.length) {
      citySel.innerHTML = cities.map(function (c, i) { return '<option value="' + i + '">' + esc(c.n) + '</option>'; }).join("");
      citySel.addEventListener("change", function () { cityIdx = Number(citySel.value); drawIO(); });
    }
    function drawIO() {
      if (!MP || !cities.length) return;
      var c = cities[cityIdx];
      $("#moon-coord").textContent = c.lat.toFixed(2) + "°N · " + c.lon.toFixed(2) + "°E";
      var sel = input.value || A.todayStr();
      var r = MP.riseSet(sel, c.lat, c.lon, 8);
      $("#moon-rise").textContent = r.rise == null ? "当日不升起" : MP.hhmm(r.rise);
      $("#moon-tran").textContent = MP.hhmm(r.tran);
      $("#moon-set").textContent = r.set == null ? "当日不落下" : MP.hhmm(r.set);
      drawNow();
    }
    function drawNow() {
      var el = $("#moon-now");
      if (!el || !MP || !cities.length) return;
      var c = cities[cityIdx];
      var jd = Date.now() / 86400000 + 2440587.5;
      var a = MP.altAt(jd, c.lat, c.lon);
      var above = a.alt > (0.7275 * a.par - 0.5667);
      el.innerHTML = "此刻（" + A.pad(new Date().getHours()) + ":" + A.pad(new Date().getMinutes()) + "）月亮" +
        (above ? '<b style="color:var(--cyan-2)">在地平线以上</b>，高度约 ' + a.alt.toFixed(0) + "°"
               : '<b style="color:var(--ink-3)">在地平线以下</b>（高度 ' + a.alt.toFixed(0) + "°）");
    }
    /* ---- 下一次朔 / 上弦 / 望 / 下弦 ---- */
    function drawNext() {
      var box = $("#moon-next");
      if (!box) return;
      var now = new Date();
      var pairs = [["朔", "新月（朔）"], ["上弦", "上弦"], ["望", "满月（望）"], ["下弦", "下弦"]];
      box.innerHTML = pairs.map(function (pp) {
        var t = A.nextPhase(pp[0], now.getTime());
        if (!t) return '<div><span>下次' + pp[1] + '</span><b class="muted">超出已整理范围</b></div>';
        var ms = t.getTime() - now.getTime();
        var d = Math.floor(ms / 86400000), h = Math.floor(ms % 86400000 / 3600000), mi2 = Math.round(ms % 3600000 / 60000);
        var left = d > 0 ? ("还有 " + d + " 天" + (h > 0 ? " " + h + " 小时" : ""))
                 : (h > 0 ? ("还有 " + h + " 小时" + (mi2 > 0 ? " " + mi2 + " 分" : "")) : ("还有 " + mi2 + " 分钟"));
        var stamp = (t.getMonth() + 1) + "/" + t.getDate() + " " + A.pad(t.getHours()) + ":" + A.pad(t.getMinutes());
        return '<div><span>下次' + pp[1] + '</span><b>' + stamp + ' <em style="font-style:normal;font-weight:500;color:var(--ink-3);font-size:12.5px">· ' + left + '</em></b></div>';
      }).join("");
    }
    input.addEventListener("change", function () { upd(); drawIO(); });
    input.addEventListener("input", function () { upd(); drawIO(); });
    $("#moon-today").addEventListener("click", function () { followed = A.todayStr(); input.value = followed; upd(); drawIO(); drawNext(); });
    upd(); drawIO(); drawNext();
    setInterval(function () {
      var t = A.todayStr();
      var jumped = false;
      if (input.value === followed && t !== followed) { followed = t; input.value = t; jumped = true; }
      upd(); drawNext(); drawNow();
      if (jumped) drawIO();
    }, 30000);
  }

  /* ---------- 未来天象看点（自动按今天滚动） ---------- */
  function future() {
    var box = $("#future-list"), range = $("#future-range");
    if (!box) return;
    var today = A.todayStr();
    var all = allEvents();
    if (!all.length) return;
    var last = all[all.length - 1];
    if (range) {
      var left = Math.round((new Date(last.e.d + "T00:00:00") - new Date(today + "T00:00:00")) / 86400000);
      range.textContent = "数据已覆盖到 " + A.fmtDate(last.e.d) + "（还剩 " + left + " 天）· 更新数据后自动延长";
    }
    var up = all.filter(function (x) { return String(x.e.d) >= today; }).slice(0, 12);
    if (!up.length) {
      box.innerHTML = '<div class="card"><p class="muted" style="margin:0">当前数据里的天象都已经过去了，快到 <a href="tools/forecast-editor.html">天象预报编辑器</a> 更新下个月的数据吧。</p></div>';
      return;
    }
    box.innerHTML = up.map(function (x, idx) {
      var days = Math.round((new Date(x.e.d + "T00:00:00") - new Date(today + "T00:00:00")) / 86400000);
      var cd = days === 0 ? "就在今天" : (days === 1 ? "明天" : "还有 " + days + " 天");
      return '<div class="ev future-ev"' + (idx === 0 ? ' style="border-color:rgba(255,212,121,.55);box-shadow:0 0 0 1px rgba(255,212,121,.25)"' : '') + ' data-ev2="' + esc(x.e.d + "|" + x.e.t) + '">' +
        '<div class="ev-date">' + A.fmtMD(x.e.d) + '<span>' + x.m.year + "." + A.pad(x.m.month) + " · 周" + A.weekday(x.e.d) + '</span><span style="color:var(--gold-2);font-weight:800">' + esc(cd) + '</span></div>' +
        '<div><h4><span class="chip ' + (TYPE_CLASS[x.e.k] || "") + '">' + esc(x.e.k) + '</span>' + esc(x.e.t) + '</h4>' +
        '<p>' + esc(x.e.desc) + '</p>' +
        (x.e.tip ? '<div class="tips">观测提示：' + esc(x.e.tip) + '　<span class="moon-tag">' + esc(A.moonTag(x.e.d)) + '</span></div>' : '') +
        '</div></div>';
    }).join("");
    $$(".future-ev", box).forEach(function (el) {
      el.addEventListener("click", function () {
        var parts = el.getAttribute("data-ev2").split("|");
        var found = allEvents().filter(function (x) { return x.e.t === parts[1] && x.e.d === parts[0]; })[0];
        if (found) openModal(found.e, found.m);
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!MONTHS.length) return;
    rail();
    state.type = "全部"; state.q = "";
    var today = A.todayStr().slice(0, 7);
    select(monthOf(today) ? today : MONTHS[MONTHS.length - 1].id);
    syncFilters();
    nowSection();
    future();

    $$("#type-filters button").forEach(function (b) {
      b.addEventListener("click", function () {
        state.type = b.getAttribute("data-t"); syncFilters(); renderFiltered();
      });
    });
    var si = $("#search-input");
    if (si) si.addEventListener("input", function () { state.q = si.value.trim(); if (state.q || state.type !== "全部") renderFiltered(); else select(state.month); });
    var stat = $("#data-stat");
    if (stat) {
      var ev = 0, sh = 0, pl = 0;
      MONTHS.forEach(function (m) {
        (m.events || []).forEach(function (e) { ev++; if (e.k === "流星雨") sh++; if (e.k === "行星" || e.k === "日月食") pl++; });
      });
      stat.innerHTML = '<b style="color:#fff">' + MONTHS.length + '</b> 期月度预报 · <b style="color:#fff">' + ev + '</b> 项天象记录 · <b style="color:#fff">' + sh + '</b> 场流星雨 · <b style="color:#fff">' + pl + '</b> 项行星与日月食事件';
    }
  });
})();
