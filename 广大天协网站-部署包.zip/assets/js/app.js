/* 通用脚本：星空背景 / 导航 / 滚动动画 / 月相计算 / 通用渲染 */
(function () {
  "use strict";

  /* ---------------- 工具 ---------------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function fmtDate(d) {
    var p = String(d).split("-");
    if (p.length < 3) return d;
    return p[0] + " 年 " + Number(p[1]) + " 月 " + Number(p[2]) + " 日";
  }
  function fmtMD(d) {
    var p = String(d).split("-");
    return p.length < 3 ? d : Number(p[1]) + "/" + Number(p[2]);
  }
  function weekday(d) {
    var t = new Date(d + "T12:00:00");
    return "日一二三四五六".charAt(t.getDay());
  }
  function todayStr() {
    var t = new Date();
    return t.getFullYear() + "-" + pad(t.getMonth() + 1) + "-" + pad(t.getDate());
  }

  /* ---------------- 月相 ----------------
     数据覆盖范围内（2025-09 起）：用数据文件里的精确朔 / 上弦 / 望 / 下弦时刻插值，
     越靠近朔望越准（朔望时刻由香港天文台、紫金山天文台数据核对）。
     超出数据范围：回退到平均朔望周期近似算法（误差约 ±0.5 天）。
     返回：{ age, illum, name, emoji, method }，method 为 exact / approx */
  var SYNODIC = 29.530588853;
  var REF_NEW = 2451550.1; /* 2000-01-06 18:14 UTC 的朔 */
  /* 四个节点的"月日角"（太阳—地球—月亮的夹角，单位：度）。照明度 = (1 - cos E) / 2，
     而 E 随时间近似匀速增加，所以在相邻节点之间用线性插值比直接插值照明度准得多。 */
  var ANCHOR_ELONG = { "朔": 0, "上弦": 90, "望": 180, "下弦": 270 };
  var PHASE_NAMES = [
    [1.0, "新月（朔）", "🌑"], [5.5, "娥眉月", "🌒"], [9.2, "上弦月", "🌓"],
    [12.9, "盈凸月", "🌔"], [16.6, "满月（望）", "🌕"], [20.3, "亏凸月", "🌖"],
    [23.9, "下弦月", "🌗"], [27.7, "残月", "🌘"], [99, "新月（朔）", "🌑"]
  ];
  function meanAge(date) {
    var jd = date.getTime() / 86400000 + 2440587.5;
    var age = (jd - REF_NEW) % SYNODIC;
    if (age < 0) age += SYNODIC;
    return age;
  }
  var anchors = null;
  function buildAnchors() {
    anchors = [];
    var months = (window.SKY_DATA && window.SKY_DATA.months) || [];
    months.forEach(function (m) {
      (m.phases || []).forEach(function (p) {
        if (!p || !p.d) return;
        var v = ANCHOR_ELONG[p.n];
        if (v == null) return;
        var t = (p.t && /^\d{1,2}:\d{2}$/.test(p.t)) ? p.t : "12:00";
        if (t.length === 4) t = "0" + t;
        var ms = new Date(p.d + "T" + t + ":00").getTime();
        if (!isNaN(ms)) anchors.push({ t: ms, v: v, n: p.n });
      });
    });
    anchors.sort(function (a, b) { return a.t - b.t; });
    return anchors;
  }
  /* 按"月日角"判定月相名称（0°=朔，90°=上弦，180°=望，270°=下弦） */
  function nameByElong(e) {
    if (e < 10 || e >= 350) return ["新月（朔）", "🌑"];
    if (e < 80) return ["娥眉月", "🌒"];
    if (e < 100) return ["上弦月", "🌓"];
    if (e < 170) return ["盈凸月", "🌔"];
    if (e < 190) return ["满月（望）", "🌕"];
    if (e < 260) return ["亏凸月", "🌖"];
    if (e < 280) return ["下弦月", "🌗"];
    return ["残月", "🌘"];
  }
  function moonPhase(date) {
    var ms = date.getTime();
    if (!anchors) buildAnchors();
    var lo = null, hi = null, li = -1, i;
    for (i = 0; i < anchors.length; i++) {
      if (anchors[i].t <= ms) { lo = anchors[i]; li = i; } else { hi = anchors[i]; break; }
    }
    var age = meanAge(date), illum = null, method = "approx", elong = null;
    if (lo && hi) {
      var frac = (ms - lo.t) / (hi.t - lo.t);
      var e0 = lo.v, e1 = hi.v;
      if (e1 <= e0) e1 += 360;                      /* 下弦(270°) → 朔(0°) 时跨过 360° */
      elong = ((e0 + (e1 - e0) * frac) % 360 + 360) % 360;
      illum = (1 - Math.cos(elong * Math.PI / 180)) / 2;
      method = "exact";
      for (i = li; i >= 0; i--) {
        if (anchors[i].n === "朔") { age = (ms - anchors[i].t) / 86400000; break; }
      }
      if (age >= SYNODIC) age = age % SYNODIC;
    }
    if (illum == null || isNaN(illum)) illum = (1 - Math.cos(2 * Math.PI * age / SYNODIC)) / 2;
    var name, emoji;
    if (method === "exact") {
      var pp = nameByElong(elong);
      name = pp[0]; emoji = pp[1];
    } else {
      name = PHASE_NAMES[PHASE_NAMES.length - 1][1]; emoji = PHASE_NAMES[PHASE_NAMES.length - 1][2];
      for (i = 0; i < PHASE_NAMES.length; i++) {
        if (age < PHASE_NAMES[i][0]) { name = PHASE_NAMES[i][1]; emoji = PHASE_NAMES[i][2]; break; }
      }
    }
    return { age: age, illum: illum, name: name, emoji: emoji, method: method, elong: (method === "exact" ? elong : age / SYNODIC * 360) };
  }
  /* 下一次某个相位（朔/上弦/望/下弦） */
  function nextPhase(name, ms) {
    if (!anchors) buildAnchors();
    for (var i = 0; i < anchors.length; i++) {
      if (anchors[i].n === name && anchors[i].t > ms) return new Date(anchors[i].t);
    }
    return null;
  }
  function moonIllum(date) { return moonPhase(date).illum; }
  function moonAge(date) { return moonPhase(date).age; }
  function moonTag(dateStr) {
    var d = new Date(dateStr + "T20:00:00");
    if (isNaN(d.getTime())) return "";
    var p = moonPhase(d);
    var pct = Math.round(p.illum * 100);
    var level = pct < 15 ? "无月光干扰" : pct < 40 ? "月光干扰小" : pct < 70 ? "月光干扰中等" : "月光干扰较大";
    return "月相 " + p.emoji + " " + p.name + "（约 " + pct + "%）· " + level;
  }

  /* ---------------- 星空背景 ---------------- */
  function starfield() {
    var cv = $("#starfield");
    if (!cv || !cv.getContext) return;
    var ctx = cv.getContext("2d");
    var w = 0, h = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);
    var stars = [], shots = [], reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    function resize() {
      w = cv.width = Math.floor(innerWidth * dpr);
      h = cv.height = Math.floor(innerHeight * dpr);
      cv.style.width = innerWidth + "px";
      cv.style.height = innerHeight + "px";
      var n = Math.round(innerWidth * innerHeight / 9000);
      stars = [];
      for (var i = 0; i < n; i++) {
        stars.push({
          x: Math.random() * w, y: Math.random() * h,
          r: (Math.random() * 1.3 + 0.35) * dpr,
          a: Math.random() * 0.6 + 0.25,
          s: Math.random() * 0.9 + 0.25,
          p: Math.random() * Math.PI * 2,
          warm: Math.random() < 0.14
        });
      }
    }
    function draw(t) {
      ctx.clearRect(0, 0, w, h);
      for (var i = 0; i < stars.length; i++) {
        var st = stars[i];
        var tw = reduced ? st.a : st.a + Math.sin(t / 1100 * st.s + st.p) * 0.28;
        if (tw < 0.05) tw = 0.05;
        ctx.beginPath();
        ctx.fillStyle = st.warm ? "rgba(255,226,168," + tw + ")" : "rgba(214,232,255," + tw + ")";
        ctx.arc(st.x, st.y, st.r, 0, 6.2832);
        ctx.fill();
      }
      if (!reduced) {
        if (shots.length < 2 && Math.random() < 0.004) {
          shots.push({ x: Math.random() * w * 0.8, y: Math.random() * h * 0.4, l: 0, len: (Math.random() * 130 + 90) * dpr, sp: (Math.random() * 4 + 5) * dpr });
        }
        for (var k = shots.length - 1; k >= 0; k--) {
          var s = shots[k];
          s.l += s.sp;
          var x1 = s.x + s.l * 0.86, y1 = s.y + s.l * 0.5;
          var g = ctx.createLinearGradient(x1, y1, x1 - s.len * 0.86, y1 - s.len * 0.5);
          g.addColorStop(0, "rgba(255,255,255,0.9)");
          g.addColorStop(1, "rgba(140,200,255,0)");
          ctx.strokeStyle = g; ctx.lineWidth = 1.6 * dpr;
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - s.len * 0.86, y1 - s.len * 0.5); ctx.stroke();
          if (s.l > s.len * 2.2) shots.splice(k, 1);
        }
      }
      requestAnimationFrame(draw);
    }
    resize();
    addEventListener("resize", resize);
    requestAnimationFrame(draw);
  }

  /* ---------------- 导航 / 滚动动画 ---------------- */
  function nav() {
    var btn = $(".nav-toggle"), links = $(".nav-links");
    if (!btn || !links) return;
    function setOpen(open) {
      links.classList.toggle("open", open);
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      btn.textContent = open ? "✕" : "☰";
    }
    btn.setAttribute("aria-expanded", "false");
    btn.addEventListener("click", function (ev) {
      if (ev && ev.stopPropagation) ev.stopPropagation();
      setOpen(!links.classList.contains("open"));
    });
    $$("a", links).forEach(function (a) {
      a.addEventListener("click", function () { setOpen(false); });
    });
    document.addEventListener("click", function (ev) {
      if (!links.classList.contains("open")) return;
      if ((links.contains && links.contains(ev.target)) || (btn.contains && btn.contains(ev.target))) return;
      setOpen(false);
    });
    addEventListener("resize", function () { if (innerWidth > 760) setOpen(false); });
  }
  function reveal() {
    var els = $$(".reveal");
    if (!els.length) return;
    if (!("IntersectionObserver" in window)) { els.forEach(function (e) { e.classList.add("in"); }); return; }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    els.forEach(function (e) { io.observe(e); });
  }

  /* ---------------- 页面渲染 ---------------- */
  /* ---------------- 公众号推文档案（封面来自公众号原文） ---------------- */
  var artState = { year: "all", cat: "all" };
  function artAll() {
    var src = (window.ARTICLES && window.ARTICLES.items) || [];
    return src.slice().sort(function (a, b) { return String(b.d).localeCompare(String(a.d)); });
  }
  function artFiltered() {
    var list = artAll();
    if (artState.year !== "all") list = list.filter(function (x) { return String(x.d).slice(0, 4) === artState.year; });
    if (artState.cat !== "all") list = list.filter(function (x) { return x.cat === artState.cat; });
    return list;
  }
  function artCard(a) {
    var cover = a.cover ? '<img src="' + esc(a.cover) + '" alt="' + esc(a.t) + '" loading="lazy">' : "";
    return '<article class="card arc reveal in" data-id="' + esc(a.id) + '">' +
      '<div class="arc-cover">' + cover + '<span class="arc-badge chip violet">' + esc(a.cat) + '</span></div>' +
      '<div class="arc-body">' +
        '<div class="arc-meta"><span>' + fmtDate(a.d) + '</span></div>' +
        '<h4>' + esc(a.t) + '</h4>' +
      '</div></article>';
  }
  function renderArticles() {
    var box = $("#article-list");
    if (!box || !window.ARTICLES) return;
    var limit = parseInt(box.getAttribute("data-limit"), 10);
    var list = isNaN(limit) ? artFiltered() : artAll().slice(0, limit);
    box.innerHTML = list.length ? list.map(artCard).join("") : '<p class="muted">没有符合条件的推文。</p>';
    $$(".arc", box).forEach(function (el) {
      el.addEventListener("click", function () {
        var a = artAll().filter(function (x) { return x.id === el.getAttribute("data-id"); })[0];
        if (a) openArticle(a);
      });
    });
    var stat = $("#art-stat");
    if (stat && !isNaN(limit)) return;
    if (stat) {
      var total = artAll().length, oneYear = artAll().filter(function (x) { return x.d >= oneYearAgo(); }).length;
      stat.innerHTML = '共 <b style="color:#fff">' + total + '</b> 篇 · 近一年 <b style="color:#fff">' + oneYear + '</b> 篇 · 时间跨度 ' +
        esc(artAll()[total - 1].d) + ' 至 ' + esc(artAll()[0].d);
    }
  }
  function oneYearAgo() {
    var d = new Date(); d.setFullYear(d.getFullYear() - 1);
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }
  function renderArtFilters() {
    var yBox = $("#art-years"), cBox = $("#art-cats");
    var all = artAll();
    if (yBox) {
      var years = {};
      all.forEach(function (x) { var y = String(x.d).slice(0, 4); years[y] = (years[y] || 0) + 1; });
      var yn = Object.keys(years).sort().reverse();
      yBox.innerHTML = '<button data-year="all" class="on">全部 ' + all.length + '</button>' +
        yn.map(function (y) { return '<button data-year="' + y + '">' + y + ' 年 · ' + years[y] + '</button>'; }).join("");
      $$("button", yBox).forEach(function (b) {
        b.addEventListener("click", function () {
          artState.year = b.getAttribute("data-year");
          $$("button", yBox).forEach(function (x) { x.classList.toggle("on", x === b); });
          renderArticles();
        });
      });
    }
    if (cBox) {
      var cats = {};
      all.forEach(function (x) { cats[x.cat] = (cats[x.cat] || 0) + 1; });
      var order = ["天象预报", "活动", "赛事", "社团", "故事", "人物档案"];
      var names = order.filter(function (k) { return cats[k]; }).concat(Object.keys(cats).filter(function (k) { return order.indexOf(k) < 0; }));
      cBox.innerHTML = '<button data-cat="all" class="on">全部类型</button>' +
        names.map(function (k) { return '<button data-cat="' + esc(k) + '">' + esc(k) + ' · ' + cats[k] + '</button>'; }).join("");
      $$("button", cBox).forEach(function (b) {
        b.addEventListener("click", function () {
          artState.cat = b.getAttribute("data-cat");
          $$("button", cBox).forEach(function (x) { x.classList.toggle("on", x === b); });
          renderArticles();
        });
      });
    }
  }
  function openArticle(a) {
    var box = $("#art-modal");
    if (!box) return;
    var pts = (a.points && a.points.length) ? '<ul class="art-points">' + a.points.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>" : "";
    box.innerHTML = '<div class="modal-box">' +
      '<button class="modal-close" aria-label="关闭">✕</button>' +
      (a.cover ? '<img src="' + esc(a.cover) + '" alt="" style="width:100%;border-radius:14px;margin:6px 0 14px">' : "") +
      '<div class="art-meta"><span class="chip violet">' + esc(a.cat) + '</span><span>' + fmtDate(a.d) + '</span>' +
      (a.alb ? '<span class="chip">合集 · ' + esc(a.alb) + '</span>' : "") + '</div>' +
      '<h3 style="margin:12px 0 10px;font-size:21px;line-height:1.5">' + esc(a.t) + '</h3>' +
      (a.sum ? '<p style="color:var(--ink-2)">' + esc(a.sum) + '</p>' : "") + pts +
      '<p><a class="btn primary" href="' + esc(a.url) + '" target="_blank" rel="noopener">在微信中阅读原文 →</a></p>' +
      '</div>';
    box.classList.add("on");
    $(".modal-close", box).addEventListener("click", function () { box.classList.remove("on"); });
    box.addEventListener("click", function (ev) { if (ev.target === box) box.classList.remove("on"); });
  }

  function renderHomeBits() {
    if (!window.SITE) return;
    var m = window.SITE.mascot;
    $$("[data-mascot-name]").forEach(function (e) { e.textContent = m.name; });
    $$("[data-club-short]").forEach(function (e) { e.textContent = window.SITE.club.short; });
    var stats = $("#club-stats");
    if (stats) stats.innerHTML = window.SITE.club.stats.map(function (s) {
      return '<div><b>' + esc(s.b) + '</b><span>' + esc(s.s) + '</span></div>';
    }).join("");
    var pro = $("#mascot-profile");
    if (pro) pro.innerHTML = m.profile.map(function (p) {
      return '<div><b>' + esc(p.k) + '</b><span>' + esc(p.v) + '</span></div>';
    }).join("");
    var lines = $("#mascot-lines");
    if (lines) lines.innerHTML = m.lines.map(function (l) { return '<div class="line-bubble">' + esc(l) + '</div>'; }).join("");
    var nam = $("#mascot-naming");
    if (nam) nam.innerHTML = m.naming.map(function (n, i) {
      return '<div class="card reveal" style="margin-bottom:16px"><h3 style="font-size:18px">' + (i + 1) + '. ' + esc(n.t) + '</h3><p class="muted" style="margin:0">' + esc(n.d) + '</p></div>';
    }).join("");
    var acts = $("#activity-list");
    if (acts) acts.innerHTML = window.SITE.activities.map(function (a) {
      return '<div class="act reveal"><div class="when">' + esc(a.when) + '</div><div><h4>' + esc(a.t) + '</h4><p>' + esc(a.d) + '</p></div></div>';
    }).join("");
    var join = $("#join-list");
    if (join) join.innerHTML = window.SITE.join.map(function (j) {
      return '<details class="qa reveal"><summary>' + esc(j.q) + '</summary><p>' + esc(j.a) + '</p></details>';
    }).join("");
    var src = $("#source-list");
    if (src) src.innerHTML = window.SITE.sources.map(function (s) {
      return '<li><a href="' + esc(s.u) + '" target="_blank" rel="noopener">' + esc(s.n) + '</a> · ' + esc(s.d) + '</li>';
    }).join("");
    var dep = $("#dept-list");
    if (dep) dep.innerHTML = window.SITE.club.departments.map(function (d) {
      return '<div class="card" style="padding:18px"><h4 style="font-size:16px;color:#fff;margin-bottom:6px">' + esc(d.n) + '</h4><p class="muted small" style="margin:0">' + esc(d.d) + '</p></div>';
    }).join("");
  }

  /* ---------------- 首页：本月提示 ---------------- */
  function renderHomeNext() {
    var box = $("#home-next");
    if (!box || !window.SKY_DATA) return;
    var today = todayStr();
    var all = [];
    window.SKY_DATA.months.forEach(function (m) {
      m.events.forEach(function (e) { all.push({ m: m, e: e }); });
    });
    all.sort(function (a, b) { return String(a.e.d).localeCompare(String(b.e.d)); });
    var up = all.filter(function (x) { return String(x.e.d) >= today; }).slice(0, 4);
    if (!up.length) up = all.slice(-4);
    box.innerHTML = up.map(function (x) {
      return '<li><span class="d">' + fmtMD(x.e.d) + '</span><span><b style="color:#fff">' + esc(x.e.t) + '</b><br><span class="small muted">' + esc(x.m.year + " 年 " + x.m.name) + ' · ' + esc(x.e.k) + '</span></span></li>';
    }).join("");
  }

  document.addEventListener("DOMContentLoaded", function () {
    starfield(); nav(); renderArticles(); renderArtFilters(); renderHomeBits(); renderHomeNext(); reveal();
  });

  window.APP = {
    $: $, $$: $$, esc: esc, pad: pad, fmtDate: fmtDate, fmtMD: fmtMD, weekday: weekday,
    todayStr: todayStr, moonPhase: moonPhase, moonIllum: moonIllum, moonAge: moonAge, moonTag: moonTag,
    nextPhase: nextPhase, hasAnchors: function () { return !!(window.SKY_DATA && window.SKY_DATA.months && window.SKY_DATA.months.length); }
  };
})();
